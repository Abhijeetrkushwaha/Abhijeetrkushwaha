<a href='https://twitter.com/${follower_screen_name}'>
  <img style="border-radius:50%" align="left" src='${follower_profile_image_url_https}' />
</a>

<a href='https://twitter.com/${follower_screen_name}'>
    ${follower_name}
</a>

${follower_description}

<h2></h2>